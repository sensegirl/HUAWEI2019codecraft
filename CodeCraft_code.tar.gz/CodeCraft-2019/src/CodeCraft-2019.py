import logging
import sys

logging.basicConfig(level=logging.DEBUG,
                    filename='../logs/CodeCraft-2019.log',
                    format='[%(asctime)s] %(levelname)s [%(funcName)s: %(filename)s, %(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S',
                    filemode='a')


def main():
    if len(sys.argv) != 5:
        logging.info('please input args: car_path, road_path, cross_path, answerPath')
        exit(1)

    car_path = sys.argv[1]
    road_path = sys.argv[2]
    cross_path = sys.argv[3]
    answer_path = sys.argv[4]

    logging.info("car_path is %s" % (car_path))
    logging.info("road_path is %s" % (road_path))
    logging.info("cross_path is %s" % (cross_path))
    logging.info("answer_path is %s" % (answer_path))


    
    # coding: utf-8
    

# coding: utf-8

# In[1]:

##coding by wangzengkun
##20190314
##使用官网数据进行路径选择
#floyd
##问题：针对方阵，地图方阵为17*17，且结点地图边长手动给出8     后期可能需要调整
#floyd版本2

#1.考虑路宽，将floyd矩阵的元素计算时考虑路宽（调整kuanb）
#考虑路宽后时间会有小幅提升，很小，但是趋向于走宽路死锁的几率貌似会增大一些
#2.此版本把直行车辆单独分离出来了
#3.准备考虑每个路口的转弯情况，尝试优化死锁问题,给folyd矩阵增加直行奖励常数stritaward
#  虽然按比例K直行奖赏貌似更合理，但实际情况是，直接每多一次直行减少1.2最为有效，但是图一总是锁死，所以现在没有选用大的奖赏
#  增大了快路与慢路的差距
# 4.尝试让左上到右下，右下到左上两个里的慢车先走（降序排列），防止和后一批车死锁，效果不佳，已去除这个功能
# 5.将直行放在中间阻隔两股车流，防止锁死
# 6.次干道权值法
# 7.第一批批量大
# 8.增加了先按车速排再按路线排序


    # In[2]:
    
    ##官网示例数据读取
    import numpy as np
    import copy
    import random
    
    ##读取车辆信息
    with open(car_path,'r') as f:
        next(f)    ##跳过txt中第一行注释
        list_arr = f.readlines()
        l = len(list_arr)
        for i in range(l):
            list_arr[i] = list_arr[i].strip()
            list_arr[i] = list_arr[i].strip('()')  ##去掉首位括号
            list_arr[i] = list_arr[i].split(',')   ##以逗号分割
    car = np.array(list_arr)
    car = car.astype(int)
    f.close()
    n_car = car.shape[0]   ## car矩阵的行数----车辆数目
    carstart = 10000      #开始序号
    
    ##读取路口信息
    with open(cross_path,'r') as f:
        next(f)    ##跳过txt中第一行注释
        list_arr = f.readlines()
        l = len(list_arr)
        for i in range(l):
            list_arr[i] = list_arr[i].strip()
            list_arr[i] = list_arr[i].strip('()')  ##去掉首位括号
            list_arr[i] = list_arr[i].split(',')   ##以逗号分割
    cross = np.array(list_arr)
    cross = cross.astype(int)
    f.close()
    n_cross = cross.shape[0]   ## cross矩阵的行数----路口数目
    crossstart = 1
    
    ##读取道路信息
    with open(road_path,'r') as f:
        next(f)    ##跳过txt中第一行注释
        list_arr = f.readlines()
        l = len(list_arr)
        for i in range(l):
            list_arr[i] = list_arr[i].strip()
            list_arr[i] = list_arr[i].strip('()')  ##去掉首尾括号
            list_arr[i] = list_arr[i].split(',')   ##以逗号分割
    road = np.array(list_arr)
    road = road.astype(int)
    f.close()
    n_road = road.shape[0]   ## road矩阵的行数----道路数目
    roadstart = 5000
    
    

# coding: utf-8
    
    # In[1]:
    
    ##coding by wangzengkun
    ##20190314
    ##使用官网数据进行路径选择
    #floyd
    ##问题：针对方阵，地图方阵为17*17，且结点地图边长手动给出8     后期可能需要调整
    #floyd版本2
    
    #1.考虑路宽，将floyd矩阵的元素计算时考虑路宽（调整kuanb）
    #考虑路宽后时间会有小幅提升，很小，但是趋向于走宽路死锁的几率貌似会增大一些
    #2.此版本把直行车辆单独分离出来了
    #3.准备考虑每个路口的转弯情况，尝试优化死锁问题,给folyd矩阵增加直行奖励常数stritaward
    #  虽然按比例K直行奖赏貌似更合理，但实际情况是，直接每多一次直行减少1.2最为有效，但是图一总是锁死，所以现在没有选用大的奖赏
    #  增大了快路与慢路的差距
    # 4.尝试让左上到右下，右下到左上两个里的慢车先走（降序排列），防止和后一批车死锁，效果不佳，已去除这个功能
    # 5.将直行放在中间阻隔两股车流，防止锁死
    # 6.次干道权值法
    # 7.第一批批量大
    # 8.增加了先按车速排再按路线排序
    # In[3]:
    
    #对道路进行处理
    #判断道路是否为单行道和边路
    sideroad = []
    sidecross = [] #连接两个边点的就是边路,暂定连接三通和两桶边点的都是边路
    sroad = []#单行道
    
    for i in road:
        if i[6]==0:
            sroad.append(i[0])#单行道
    
    #找边点
    three = 0
    three_cross = []
    two = 0
    two_cross = []
    one = 0
    one_cross = []
    four = 0
    four_cross = []
    for i in cross:
        temp = 0
        for j in i:
            if j == -1:
                temp+=1
        if temp==2:
            two+=1
            two_cross.append(i[0])
            sidecross.append(i[0])
        elif temp==3:
            one+=1
            one_cross.append(i[0])
            sidecross.append(i[0])
#       elif temp==1:
#            three+=1
#            three_cross.append(i[0])
#            sidecross.append(i[0])
        else:
            four_cross.append(i[0])
    
    #找边路
    for i in road:
        if i[4] in sidecross and i[5] in sidecross:
            sideroad.append(i[0])
    
    
    # In[5]:
    
    #参数设置
    kuanb = 1 #宽度通常为1-5，以（kuanb+路宽作为floyd元素权重，40-50还不错，小提升）
    bignum = 999999
    sideroadb = 0.9 #先测试，后面再加
    sroadb = 1.2  #后面再加
    def floyd(road,cross,n_cross,spdlimit):
        #floyd矩阵
        floyd = np.zeros([n_cross,n_cross])#后期可以考虑为每个车辆建立一个floyd矩阵，综合考虑车速和限速
        floydpath = []
        for i in range(n_cross):
            pp = []
            for j in range(n_cross):
                pp.append([])
            floydpath.append(pp)
        for i in range(len(road)):
            #正向
            floyd_row = -1
            floyd_col = -1
            for j in range(len(cross)):
                if cross[j][0]==road[i][4]:
                    floyd_row = j
                if cross[j][0]==road[i][5]:
                    floyd_col = j
                    
                #找到此道路的两个节点后
                if floyd_row != -1 and floyd_col != -1:
                    #正向
                    if road[i][0] in sideroad:
                        floyd[floyd_row][floyd_col] = road[i][1]/(min(road[i][2],spdlimit))/(kuanb+road[i][3])*sideroadb
                    elif road[i][0] in sroad:
                        floyd[floyd_row][floyd_col] = road[i][1]/(min(road[i][2],spdlimit))/(kuanb+road[i][3])*sroadb
                    else:
                        floyd[floyd_row][floyd_col] = road[i][1]/(min(road[i][2],spdlimit))/(kuanb+road[i][3])
                    floydpath[floyd_row][floyd_col].append(road[i][0])
                    #反向
                    if road[i][6]==1:
                        #交换起点终点位置
                        temp = floyd_row
                        floyd_row = floyd_col
                        floyd_col = temp
                        if road[i][0] in sideroad:
                            floyd[floyd_row][floyd_col] = road[i][1]/(min(road[i][2],spdlimit))/(kuanb+road[i][3])*sideroadb
                        elif road[i][0] in sroad:
                            floyd[floyd_row][floyd_col] = road[i][1]/(min(road[i][2],spdlimit))/(kuanb+road[i][3])*sroadb
                        else:
                            floyd[floyd_row][floyd_col] = road[i][1]/(min(road[i][2],spdlimit))/(kuanb+road[i][3])
                        floydpath[floyd_row][floyd_col].append(road[i][0])
                    break
    
        for i in range(n_cross):
            for j in range(n_cross):
                if floyd[i][j]==0 and i!=j:
                    floyd[i][j]=bignum
        #Floyd
        for k in range(n_cross):
            for i in range(n_cross):
                for j in range(n_cross):
                    if k==i or k==j:
                        continue
                    if floyd[i][j] > floyd[i][k]+floyd[k][j]:
                        floyd[i][j] = floyd[i][k] + floyd[k][j]
                        tmp = []
                        for item in floydpath[i][k]:
                            tmp.append(item)
                        for item in floydpath[k][j]:
                            tmp.append(item)
                        floydpath[i][j] = tmp
        return floydpath,floyd
    
    
    # In[6]:
    
    # print(maxspd)
    # print(floyd16)
    
    
    # In[7]:
    
    #求出最大最小车速
    maxspd = 0
    minspd = 10
    for i in car:
        if i[3]>maxspd:
            maxspd = i[3]
        if i[3]<minspd:
            minspd = i[3]
            
    #求出不同车速下的floyd和floydpath矩阵
    for i in range(minspd,maxspd+1):
        locals()['floydpath'+str(i)],locals()['floyd'+str(i)]=floyd(road,cross,n_cross,i)
        
    
    
    # In[8]:
    
    #将路口floyd索引和路口号对应起来，建立映射
    cross_map = np.zeros([cross[len(cross)-1][0]+1,1])
    temp = 0
    for i in cross:
        cross_map[i[0]][0] = int(temp) #路口序号为索引，值为路口排序
        temp = temp+1
    
    
    # In[9]:
    
    #临时答案汇总区
    answer = []
    for i in car:
        time = copy.deepcopy(eval('floyd'+str(i[3]))[int(cross_map[i[1]])][int(cross_map[i[2]])])
        path = copy.deepcopy(eval('floydpath'+str(i[3]))[int(cross_map[i[1]])][int(cross_map[i[2]])])
        path.insert(0,i[4])
        path.insert(0,i[0])
        path.insert(0,time)
    #     if int((i[2]-1)/crossmap_col)==int((i[1]-1)/crossmap_col):#是否同行,找出从左到右
    #         if len(path)==int((i[2]-1)%crossmap_col-(i[1]-1)%crossmap_col)+3: #是否确实中间无阻挡可以直行
    #             path.insert(0,i[3])
    #             car_strit_route.append(path)
    #             car_strit.append(i)
    #             continue
        path.insert(0,i[3])
        answer.append(path)
    
    
    # In[10]:
    
    answer.sort(key = lambda x:(-x[0],x[1]))#速度降序，距离升序
    temp = 0
    for i in answer:
        temp = temp+1
        if i[3]>int((temp/500)*15.5):
            i[3]=i[3]
            del i[0]
            del i[0]
        else:
            i[3]=int((temp/500)*15.5)
            del i[0]
            del i[0]
    
    # In[11]:
    
    # #出发时间
    # import math
    
    # new_answer = [] 
    # road_volume = 0 #地图车辆总容量 
    # for i in road:
    #     road_volume = road_volume + i[1]*i[3]*(i[6]+1)#64节点地图容量为8000多
    # #大批#
    # big_batch_ratio = 1/2.5 #每大批占道路总容量的比例（约）
    # big_batch_num = math.ceil(len(car)/int(road_volume*big_batch_ratio)) #看所有车能分几批，向上取整
    # big_batch = math.ceil(len(car)/big_batch_num)
    
    # #可修改参数(加上上面的ratio)
    # timecons1 = 0.011 #第一批时间长度参数
    # timecons = 0.012 #时间长度参数
    # stritcons = 0.1
    
    # delta = 0 #时间增量
    # timebase = 0 #时间接力
    # flag = 1 #标志，使得每大批的车不是重复排序而是首尾相接
    # for i in range(big_batch_num):
    #     #第一批
    #     if i == 0 :
    #         #左上右下右下左上
    #         templurd = []  #存储左上右下双向
    #         tempstrit = [] #直行
    #         templdru = []  #左下右上双向
    #         for j in answer[i*big_batch:(i+1)*big_batch]:
    #             if j[1] in car_lu2rd[:,0] or j[1] in car_rd2lu[:,0]:
    #                 templurd.append(j)
    #             elif j[1] in car_strit[:,0]:
    #                 tempstrit.append(j)
    #             else:templdru.append(j)
    #         if flag == 1:
    #             #每小批的量和最大时间和递增时间       
    #             small_batch = [len(templurd),len(tempstrit),len(templdru)]
    #             print(small_batch)
    #             maxtime = [templurd[len(templurd)-1][0]*(kuanb+4),tempstrit[len(tempstrit)-1][0]*(kuanb+4),templdru[len(templdru)-1][0]*(kuanb+4)]
    #             #每小批间隔与前一批最久时间和前一批数量有关
    #             delta_t = [int(maxtime[0]+(small_batch[0])*timecons1),int(maxtime[1]+(small_batch[1])*timecons1),
    #                        int(maxtime[2]+(small_batch[2])*timecons1)] 
    #             for j in templurd:
    #                 j[2]+= timebase 
    #                 del j[0]
    #             timebase += delta_t[0]
    #             timebase += delta_t[1]
    #             for j in tempstrit:
    #                 j[2]+= int(timebase-stritcons*delta_t[1])
    #                 del j[0]
    #             for j in templdru:
    #                 j[2]+= timebase
    #                 del j[0]
    #             timebase += delta_t[2]
    #             for item in templurd:
    #                 new_answer.append(item)
    #             for item in tempstrit:            
    #                 new_answer.append(item)
    #             for item in templdru:  
    #                 new_answer.append(item)
    #             flag = flag*(-1)
    #     #中间批
    #     elif i != big_batch_num-1 and i!=0:
    #         #左上右下右下左上
    #         templurd = []  #存储左上右下双向
    #         tempstrit = [] #直行
    #         templdru = []  #左下右上双向
    #         for j in answer[i*big_batch:(i+1)*big_batch]:
    #             if j[1] in car_lu2rd[:,0] or j[1] in car_rd2lu[:,0]:
    #                 templurd.append(j)
    #             elif j[1] in car_strit[:,0]:
    #                 tempstrit.append(j)
    #             else:templdru.append(j)
    #         if flag == 1:
    #             #每小批的量和最大时间和递增时间       
    #             small_batch = [len(templurd),len(tempstrit),len(templdru)]
    #             print(small_batch)
    #             maxtime = [templurd[len(templurd)-1][0]*(kuanb+4),tempstrit[len(tempstrit)-1][0]*(kuanb+4),templdru[len(templdru)-1][0]*(kuanb+4)]
    #             #每小批间隔与前一批最久时间和前一批数量有关
    #             delta_t = [int(maxtime[0]+(small_batch[0])*timecons),int(maxtime[1]+(small_batch[1])*timecons),
    #                        int(maxtime[2]+(small_batch[2])*timecons)] 
    #             for j in templurd:
    #                 j[2]+= timebase 
    #                 del j[0]
    #             timebase += delta_t[0]
    #             timebase += delta_t[1]
    #             for j in tempstrit:
    #                 j[2]+= int(timebase-stritcons*delta_t[1])
    #                 del j[0]
    #             for j in templdru:
    #                 j[2]+= timebase
    #                 del j[0]
    #             timebase += delta_t[2]
    #             for item in templurd:
    #                 new_answer.append(item)
    #             for item in tempstrit:            
    #                 new_answer.append(item)
    #             for item in templdru:  
    #                 new_answer.append(item)
    #             flag = flag*(-1)
    #         elif flag == -1:
    #             #每小批的量和最大时间和递增时间       
    #             small_batch = [len(templdru),len(tempstrit),len(templurd)]
    #             maxtime = [templdru[len(templdru)-1][0]*(kuanb+4),tempstrit[len(tempstrit)-1][0]*(kuanb+4),templurd[len(templurd)-1][0]*(kuanb+4)]
    #             #每小批间隔与前一批最久时间和前一批数量有关
    #             delta_t = [int(maxtime[0]+(small_batch[0])*timecons),int(maxtime[1]+(small_batch[1])*timecons),
    #                        int(maxtime[2]+(small_batch[2])*timecons)] 
    #             for j in templdru:
    #                 j[2]+= timebase 
    #                 del j[0]
    #             timebase += delta_t[0]
    #             timebase += delta_t[1]
    #             for j in tempstrit:
    #                 j[2]+= int(timebase-stritcons*delta_t[1])
    #                 del j[0]
    #             for j in templurd:
    #                 j[2]+= timebase
    #                 del j[0]
    #             timebase += delta_t[2]
    #             for item in templurd:
    #                 new_answer.append(item)
    #             for item in tempstrit:            
    #                 new_answer.append(item)
    #             for item in templdru:  
    #                 new_answer.append(item)
    #             flag = flag*(-1)
    
    #     #是最后一批
    #     else:
    #         #左上右下右下左上
    #         templurd = []  #存储左上右下双向
    #         tempstrit = [] #直行
    #         templdru = []  #左下右上双向
    #         for j in answer[i*big_batch:len(answer)]:
    #             if j[1] in car_lu2rd[:,0] or j[1] in car_rd2lu[:,0]:
    #                 templurd.append(j)
    #             elif j[1] in car_strit[:,0]:
    #                 tempstrit.append(j)
    #             else:templdru.append(j)
    #         if flag == 1:
    #             #每小批的量和最大时间和递增时间       
    #             small_batch = [len(templurd),len(tempstrit),len(templdru)]
    #             maxtime = [templurd[len(templurd)-1][0]*(kuanb+4),tempstrit[len(tempstrit)-1][0]*(kuanb+4),templdru[len(templdru)-1][0]*(kuanb+4)]
    #             #每小批间隔与前一批最久时间和前一批数量有关
    #             delta_t = [int(maxtime[0]+(small_batch[0])*timecons),int(maxtime[1]+(small_batch[1])*timecons),
    #                        int(maxtime[2]+(small_batch[2])*timecons)] 
    #             for j in templurd:
    #                 j[2]+= timebase 
    #                 del j[0]
    #             timebase += delta_t[0]
    #             timebase += delta_t[1]
    #             for j in tempstrit:
    #                 j[2]+= int(timebase-stritcons*delta_t[1])
    #                 del j[0]
    #             for j in templdru:
    #                 j[2]+= timebase
    #                 del j[0]
    #             timebase += delta_t[2]
    #             for item in templurd:
    #                 new_answer.append(item)
    #             for item in tempstrit:            
    #                 new_answer.append(item)
    #             for item in templdru:  
    #                 new_answer.append(item)
    #             flag = flag*(-1)
    #         elif flag == -1:
    #             #每小批的量和最大时间和递增时间       
    #             small_batch = [len(templdru),len(tempstrit),len(templurd)]
    #             maxtime = [templdru[len(templdru)-1][0]*(kuanb+4),tempstrit[len(tempstrit)-1][0]*(kuanb+4),templurd[len(templurd)-1][0]*(kuanb+4)]
    #             #每小批间隔与前一批最久时间和前一批数量有关
    #             delta_t = [int(maxtime[0]+(small_batch[0])*timecons),int(maxtime[1]+(small_batch[1])*timecons),
    #                        int(maxtime[2]+(small_batch[2])*timecons)] 
    #             for j in templdru:
    #                 j[2]+= timebase 
    #                 del j[0]
    #             timebase += delta_t[0]
    #             timebase += delta_t[1]
    #             for j in tempstrit:
    #                 j[2]+= int(timebase-stritcons*delta_t[1])
    #                 del j[0]
    #             for j in templurd:
    #                 j[2]+= timebase
    #                 del j[0]
    #             timebase += delta_t[2]
    #             for item in templurd:
    #                 new_answer.append(item)
    #             for item in tempstrit:            
    #                 new_answer.append(item)
    #             for item in templdru:  
    #                 new_answer.append(item)
    #             flag = flag*(-1)    
    # print(timebase)
    


    # In[12]:
    
    list.sort(answer)
    #写入答案文件
    with open(answer_path,'w') as f:
        print(f)
    with open(answer_path,'a') as f:
        f.write('#(carId,StartTime,RoadId...)\n')
        for i in range(len(answer)):
            s = str(answer[i]).replace('[','(').replace(']',')')
            f.write(s+'\n')
        f.close()
    
    
    # In[ ]:









if __name__ == "__main__":
    main()
